﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Roulette;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Roulette7
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        Random random = new Random();


        private void BetNumber(int num)
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Numbers(num) == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void BetDozen(int num)
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Dozens(num) == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Columns(int num)
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Columns(num) == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Lows()
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Lows() == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Highs()
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Highs() == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Evens()
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Evens() == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Odds()
        {
            int i = random.Next(38);
            int number = Wheel.numbers[i];
            Bets bet = new Bets(number);

            winLose.Text = (bet.Odds() == true) ? "You Win!".ToString() : $"Try Again \nWinning number was {number}".ToString();
        }
        private void Color(string colorChoice)
        {
            int i = random.Next(38);
            string color = Wheel.colors[i];
            Bets bet = new Bets(color);

            winLose.Text = (bet.Colors(colorChoice) == true) ? "You Win!".ToString() : $"Try Again \nWinning color was {color}".ToString();
        }


        private void Bet1(object sender, RoutedEventArgs e) => BetNumber(1);
        private void Bet2(object sender, RoutedEventArgs e) => BetNumber(2);
        private void Bet3(object sender, RoutedEventArgs e) => BetNumber(3);
        private void Bet4(object sender, RoutedEventArgs e) => BetNumber(4);
        private void Bet5(object sender, RoutedEventArgs e) => BetNumber(5);
        private void Bet6(object sender, RoutedEventArgs e) => BetNumber(6);
        private void Bet7(object sender, RoutedEventArgs e) => BetNumber(7);
        private void Bet8(object sender, RoutedEventArgs e) => BetNumber(8);
        private void Bet9(object sender, RoutedEventArgs e) => BetNumber(9);
        private void Bet10(object sender, RoutedEventArgs e) => BetNumber(10);
        private void Bet11(object sender, RoutedEventArgs e) => BetNumber(11);
        private void Bet12(object sender, RoutedEventArgs e) => BetNumber(12);
        private void Bet13(object sender, RoutedEventArgs e) => BetNumber(13);
        private void Bet14(object sender, RoutedEventArgs e) => BetNumber(14);
        private void Bet15(object sender, RoutedEventArgs e) => BetNumber(15);
        private void Bet16(object sender, RoutedEventArgs e) => BetNumber(16);
        private void Bet17(object sender, RoutedEventArgs e) => BetNumber(17);
        private void Bet18(object sender, RoutedEventArgs e) => BetNumber(18);
        private void Bet19(object sender, RoutedEventArgs e) => BetNumber(19);
        private void Bet20(object sender, RoutedEventArgs e) => BetNumber(20);
        private void Bet21(object sender, RoutedEventArgs e) => BetNumber(21);
        private void Bet22(object sender, RoutedEventArgs e) => BetNumber(22);
        private void Bet23(object sender, RoutedEventArgs e) => BetNumber(23);
        private void Bet24(object sender, RoutedEventArgs e) => BetNumber(24);
        private void Bet25(object sender, RoutedEventArgs e) => BetNumber(25);
        private void Bet26(object sender, RoutedEventArgs e) => BetNumber(26);
        private void Bet27(object sender, RoutedEventArgs e) => BetNumber(27);
        private void Bet28(object sender, RoutedEventArgs e) => BetNumber(28);
        private void Bet29(object sender, RoutedEventArgs e) => BetNumber(29);
        private void Bet30(object sender, RoutedEventArgs e) => BetNumber(30);
        private void Bet31(object sender, RoutedEventArgs e) => BetNumber(31);
        private void Bet32(object sender, RoutedEventArgs e) => BetNumber(32);
        private void Bet33(object sender, RoutedEventArgs e) => BetNumber(33);
        private void Bet34(object sender, RoutedEventArgs e) => BetNumber(34);
        private void Bet35(object sender, RoutedEventArgs e) => BetNumber(35);
        private void Bet36(object sender, RoutedEventArgs e) => BetNumber(36);
        private void Bet00(object sender, RoutedEventArgs e) => BetNumber(00);
        private void Bet0(object sender, RoutedEventArgs e) => BetNumber(0);
        private void Bet112(object sender, RoutedEventArgs e) => BetDozen(1);
        private void Bet212(object sender, RoutedEventArgs e) => BetDozen(2);
        private void Bet312(object sender, RoutedEventArgs e) => BetDozen(3);
        private void BetColumn1(object sender, RoutedEventArgs e) => Columns(1);
        private void BetColumn2(object sender, RoutedEventArgs e) => Columns(2);
        private void BetColumn3(object sender, RoutedEventArgs e) => Columns(3);
        private void Low(object sender, RoutedEventArgs e) => Lows();
        private void High(object sender, RoutedEventArgs e) => Highs();
        private void Even(object sender, RoutedEventArgs e) => Evens();
        private void Odd(object sender, RoutedEventArgs e) => Odds();
        private void Red(object sender, RoutedEventArgs e) => Color("red");
        private void Black(object sender, RoutedEventArgs e) => Color("black");

    }
}
