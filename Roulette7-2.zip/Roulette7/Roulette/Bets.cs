﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette
{
    public class Bets
    {
        public Bets(int ballLoc)
        {
            this.ballLoc = ballLoc;
        }
        public Bets(string color)
        {
            this.color = color;
        }
        public Bets(int ballLoc, string color)
        {
            this.ballLoc = ballLoc;
            this.color = color;
        }
        int ballLoc;
        string color;
        //Numbers: the number of the bin
        public bool Numbers(int yourNum) => (yourNum == ballLoc) ? true : false;
        //Evens/Odds: even or odd numbers
        public bool Evens() => (ballLoc % 2 == 0) ? true : false;
        //Evens/Odds: even or odd numbers
        public bool Odds() => (ballLoc % 2 == 0) ? false : true;
        //Reds/Blacks: red or black colored numbers
        public bool Colors(string colorChoice) => (colorChoice == color) ? true : false;
        //Lows/Highs: low (1 – 18) or high (19 – 38) numbers.
        public bool Lows() => (ballLoc < 19) ? true : false;
        //Lows/Highs: low (1 – 18) or high (19 – 38) numbers.
        public bool Highs() => (ballLoc > 18) ? true : false;
        //. Dozens: row thirds, 1 – 12, 13 – 24, 25 – 36
        public bool Dozens(int choice)
        {
            bool result = true;
            switch (choice)
            {
                case 1:
                    result = (ballLoc < 13) ? true : false;
                    break;
                case 2:
                    result = (ballLoc < 25 && ballLoc > 12) ? true : false;
                    break;
                case 3:
                    result = (ballLoc > 24) ? true : false;
                    break;
            }
            return result;
        }
        //Columns: first, second, or third columns
        public bool Columns(int choice)
        {
            bool result = true;
            int[] column1 = { 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34 };
            int[] column2 = { 2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35 };
            int[] column3 = { 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 };
            switch (choice)
            {
                case 1:
                    result = (column1.Contains(ballLoc)) ? true : false;
                    break;
                case 2:
                    result = (column2.Contains(ballLoc)) ? true : false;
                    break;
                case 3:
                    result = (column3.Contains(ballLoc)) ? true : false;
                    break;
            }
            return result;
        }
        //Street: rows, e.g., 1/2/3 or 22/23/24
        public bool Street(int choice)
        {
            bool result = true;
            int[] street1 = { 1, 2, 3 };
            int[] street2 = { 4, 5, 6 };
            int[] street3 = { 7, 8, 9 };
            int[] street4 = { 10, 11, 12 };
            int[] street5 = { 13, 14, 15 };
            int[] street6 = { 16, 17, 18 };
            int[] street7 = { 19, 20, 21 };
            int[] street8 = { 22, 23, 24 };
            int[] street9 = { 25, 26, 27 };
            int[] street10 = { 28, 29, 30 };
            int[] street11 = { 31, 32, 33 };
            int[] street12 = { 34, 35, 36 };
            switch (choice)
            {
                case 1:
                    result = (street1.Contains(choice)) ? true : false;
                    break;
                case 2:
                    result = (street2.Contains(choice)) ? true : false;
                    break;
                case 3:
                    result = (street3.Contains(choice)) ? true : false;
                    break;
                case 4:
                    result = (street4.Contains(choice)) ? true : false;
                    break;
                case 5:
                    result = (street5.Contains(choice)) ? true : false;
                    break;
                case 6:
                    result = (street6.Contains(choice)) ? true : false;
                    break;
                case 7:
                    result = (street7.Contains(choice)) ? true : false;
                    break;
                case 8:
                    result = (street8.Contains(choice)) ? true : false;
                    break;
                case 9:
                    result = (street9.Contains(choice)) ? true : false;
                    break;
                case 10:
                    result = (street10.Contains(choice)) ? true : false;
                    break;
                case 11:
                    result = (street11.Contains(choice)) ? true : false;
                    break;
                case 12:
                    result = (street12.Contains(choice)) ? true : false;
                    break;
            }
            return result;
        }
        //6 Numbers: double rows, e.g., 1/2/3/4/5/6 or 22/23/24/25/26/26
        public bool DoubleRows(int choice)
        {
            bool result = true;
            int[] street1 = { 1, 2, 3, 4, 5, 6 };
            int[] street2 = { 7, 8, 9, 10, 11, 12 };
            int[] street3 = { 13, 14, 15, 16, 17, 18 };
            int[] street4 = { 19, 20, 21, 22, 23, 24 };
            int[] street5 = { 25, 26, 27, 28, 29, 30 };
            int[] street6 = { 31, 32, 33, 34, 35, 36 };
            switch (choice)
            {
                case 1:
                    result = (street1.Contains(choice)) ? true : false;
                    break;
                case 2:
                    result = (street2.Contains(choice)) ? true : false;
                    break;
                case 3:
                    result = (street3.Contains(choice)) ? true : false;
                    break;
                case 4:
                    result = (street4.Contains(choice)) ? true : false;
                    break;
                case 5:
                    result = (street5.Contains(choice)) ? true : false;
                    break;
                case 6:
                    result = (street6.Contains(choice)) ? true : false;
                    break;
            }
            return result;
        }
        //Split: at the edge of any two contiguous numbers, e.g., 1/2, 11/14, and 35/36
        public bool Split(int choice1, int choice2) => (ballLoc == choice1 || ballLoc == choice2) ? true : false;
        //Corner: at the intersection of any four contiguous numbers, e.g., 1/2/4/5, or 23/24/26/27
        public bool Corner(int choice1, int choice2, int choice3, int choice4) => (ballLoc == choice1 || ballLoc == choice2 || ballLoc == choice3 || ballLoc == choice4) ? true : false;
    }
}
