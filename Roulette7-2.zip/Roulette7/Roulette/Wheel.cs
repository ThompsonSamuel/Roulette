﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Media.Miracast;

namespace Roulette
{
    public class Wheel
    {

        public static int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 0, 00 };
        public static string[] colors = Colors(numbers);

        public static string[] Colors(int[] numbers)
        {
            string[] colors = new string[38];
            int[] red = { 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 };
            for (int i = 0; i < numbers.Length; i++)
            {
                if (red.Contains(numbers[i]))
                    colors[i] = "red";
                else if (numbers[i] == 0 || numbers[i] == 00)
                    colors[i] = "green";
                else
                    colors[i] = "black";
            }
            return colors;
        }
    }
}